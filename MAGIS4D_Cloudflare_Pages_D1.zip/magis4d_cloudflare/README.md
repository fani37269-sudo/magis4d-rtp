# MAGIS4D — Cloudflare Pages + Functions + D1

Paket ini mengonversi aplikasi PHP/MySQL sebelumnya menjadi static HTML + Cloudflare Pages Functions + Cloudflare D1.

## Fitur
- Landing page dua akses (User/Admin), desain dashboard lama dipertahankan.
- Halaman User membaca konten publik dari D1.
- Login Admin memakai PBKDF2-SHA256, cookie HttpOnly/Secure/SameSite, token HMAC 12 jam.
- API state membatasi data publik pada daftar key yang diizinkan.
- Pembatasan percobaan login: 8 percobaan per IP dalam 15 menit.

## Deploy
1. Buat repo GitHub baru dan upload seluruh isi folder ini (bukan folder pembungkus).
2. Cloudflare Dashboard → Workers & Pages → Create application → Pages → Connect to Git.
3. Pilih repo. Framework preset: None; Build command kosong; Build output directory: `.`. Deploy.
4. Pages project → Settings → Functions → D1 database bindings: binding name `DB`, pilih database `magis4d-db`.
5. Pages project → Settings → Variables and Secrets → add secret `AUTH_SECRET` dengan nilai acak panjang (minimal 32 byte). Redeploy.
6. Buat D1 database bernama `magis4d-db` dari Workers & Pages → D1. Salin Database ID dan ganti `GANTI_DENGAN_DATABASE_ID_D1` pada `wrangler.toml`, lalu commit/push.
7. Jalankan migrasi dari terminal lokal pada folder proyek:
   - `npx wrangler d1 migrations apply magis4d-db --remote`
8. Buat admin: `node scripts/create-admin.mjs`, isi email dan password. Salin perintah SQL yang dihasilkan dan jalankan.
9. Buka alamat `https://nama-proyek.pages.dev`, uji User dan login Admin.

## Catatan
- Jangan commit `.dev.vars` atau rahasia ke GitHub.
- Jika sudah terlanjur membuat D1 melalui dashboard, pastikan database ID pada `wrangler.toml` cocok dengan database yang di-bind.
- Data `localStorage` lama tidak otomatis dipindahkan ke D1. Setelah deploy, konten lama mungkin perlu dimasukkan ulang melalui dashboard Admin.
- Fitur push notification dan analytics di file asal masih bersifat demo.
- Uji pada staging dan buat backup D1 sebelum penggunaan produksi.
