const COOKIE = 'MAGIS4DSESSID';
const enc = new TextEncoder();
function b64url(bytes) {
  let s = ''; for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
function unb64url(s) { s=s.replace(/-/g,'+').replace(/_/g,'/'); while(s.length%4)s+='='; return Uint8Array.from(atob(s),c=>c.charCodeAt(0)); }
async function sign(value, secret) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  return b64url(new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(value))));
}
export async function makeToken(email, secret) {
  const payload=b64url(enc.encode(JSON.stringify({email,exp:Date.now()+12*60*60*1000,nonce:crypto.randomUUID()})));
  return payload+'.'+await sign(payload,secret);
}
export async function getAdmin(request, env) {
  const cookie=request.headers.get('Cookie')||'';
  const match=cookie.match(new RegExp('(?:^|;\\s*)'+COOKIE+'=([^;]+)'));
  if(!match||!env.AUTH_SECRET)return null;
  const parts=match[1].split('.'); if(parts.length!==2)return null;
  const expected=await sign(parts[0],env.AUTH_SECRET);
  if(expected!==parts[1])return null;
  try { const data=JSON.parse(new TextDecoder().decode(unb64url(parts[0]))); if(!data.email||data.exp<Date.now())return null; return data.email; } catch { return null; }
}
export function setCookie(token) { return `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=43200`; }
export function clearCookie() { return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`; }
export function json(data,status=200,headers={}) { return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}}); }
export async function verifyPassword(password, stored) {
  const [scheme,iterations,salt,expected]=String(stored||'').split('$');
  if(scheme!=='pbkdf2'||!iterations||!salt||!expected)return false;
  const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:unb64url(salt),iterations:Number(iterations)},key,256);
  return b64url(new Uint8Array(bits))===expected;
}
