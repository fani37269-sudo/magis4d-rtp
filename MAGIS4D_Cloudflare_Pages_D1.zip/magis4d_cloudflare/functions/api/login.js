import {json,makeToken,setCookie,verifyPassword} from '../_lib/auth.js';
export async function onRequestPost({request,env}) {
  if(!env.DB||!env.AUTH_SECRET)return json({ok:false,message:'Konfigurasi database atau AUTH_SECRET belum lengkap.'},500);
  let body; try{body=await request.json()}catch{return json({ok:false,message:'Format permintaan tidak valid.'},400)}
  const email=String(body.email||'').trim().toLowerCase(),password=String(body.password||'');
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!password)return json({ok:false,message:'Email atau kata sandi tidak sesuai.'},422);
  const ip=request.headers.get('CF-Connecting-IP')||'unknown';
  const count=await env.DB.prepare("SELECT COUNT(*) AS n FROM login_attempts WHERE ip=? AND attempted_at > datetime('now','-15 minutes')").bind(ip).first();
  if((count?.n||0)>=8)return json({ok:false,message:'Terlalu banyak percobaan. Coba lagi 15 menit.'},429);
  const user=await env.DB.prepare('SELECT id,email,password_hash,active FROM admins WHERE email=? LIMIT 1').bind(email).first();
  if(!user||!user.active||!(await verifyPassword(password,user.password_hash))){await env.DB.prepare('INSERT INTO login_attempts(ip) VALUES(?)').bind(ip).run();return json({ok:false,message:'Email atau kata sandi tidak sesuai.'},401)}
  await env.DB.prepare('DELETE FROM login_attempts WHERE ip=?').bind(ip).run();
  await env.DB.prepare("UPDATE admins SET last_login=datetime('now') WHERE id=?").bind(user.id).run();
  const token=await makeToken(user.email,env.AUTH_SECRET);
  return json({ok:true,email:user.email},200,{'Set-Cookie':setCookie(token)});
}
