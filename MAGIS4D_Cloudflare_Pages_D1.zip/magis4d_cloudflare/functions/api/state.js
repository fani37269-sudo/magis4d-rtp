import {json,getAdmin} from '../_lib/auth.js';
const PUBLIC_KEYS=['magis4d_branding','magis4d_banners','magis4d_detail','magis4d_provider','magis4d_games','magis4d_winners','magis4d_media','magis4d_theme'];
export async function onRequestGet({request,env}) {
  if(!env.DB)return json({ok:false,message:'Database D1 belum dikonfigurasi.'},500);
  const scope=new URL(request.url).searchParams.get('scope')==='admin'?'admin':'public';
  if(scope==='admin'&&!await getAdmin(request,env))return json({ok:false,message:'Sesi admin tidak aktif. Silakan login kembali.'},401);
  let rows;
  if(scope==='public'){const marks=PUBLIC_KEYS.map(()=>'?').join(',');rows=await env.DB.prepare(`SELECT state_key,state_value FROM site_state WHERE state_key IN (${marks})`).bind(...PUBLIC_KEYS).all();}
  else rows=await env.DB.prepare('SELECT state_key,state_value FROM site_state').all();
  const data={};for(const r of rows.results||[])data[r.state_key]=r.state_value;
  return json({ok:true,data});
}
export async function onRequestPost({request,env}) {
  if(!await getAdmin(request,env))return json({ok:false,message:'Sesi admin tidak aktif. Silakan login kembali.'},401);
  let body;try{body=await request.json()}catch{return json({ok:false,message:'Format permintaan tidak valid.'},400)}
  const key=String(body.key||''),value=String(body.value??'');
  if(!/^magis4d_[a-z0-9_]{1,60}$/.test(key))return json({ok:false,message:'Nama data tidak valid.'},422);
  if(value.length>5000000)return json({ok:false,message:'Ukuran data melebihi batas 5 MB.'},413);
  await env.DB.prepare("INSERT INTO site_state(state_key,state_value,updated_at) VALUES(?,?,datetime('now')) ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value,updated_at=datetime('now')").bind(key,value).run();
  return json({ok:true});
}
